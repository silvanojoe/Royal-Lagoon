export default function Header(){
  return (
    <header>
      <div className="langbar">
        <div>Language</div>
        <div>
          <button className="lang">Swahili</button>
          <button className="lang">English</button>
        </div>
      </div>
      <div className="topbar">
        <div className="logo">Royal Lagoon Financial Service</div>
        <nav>
          <a href="#about">About Us</a>
          <a href="#services">Services</a>
          <a href="#serve">Who We Serve</a>
          <input type="search" placeholder="Search..." />
          <a href="#contact">Contact</a>
          <a href="/login">Login</a>
        </nav>
      </div>
    </header>
  )
}
