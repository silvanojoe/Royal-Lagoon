export const metadata = {
  title: "Royal Lagoon Financial Service",
  description: "Super Agent & Mobile Money Services",
};

import "./globals.css";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
