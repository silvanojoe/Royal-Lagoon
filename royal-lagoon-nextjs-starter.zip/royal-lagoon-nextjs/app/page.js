import Header from "../components/Header";

export default function Home(){
  return (
    <>
      <Header />
      <main>
        <section className="hero">
          <h1>Royal Lagoon Financial Service</h1>
          <p>Trusted Super Agent for M-Pesa, Tigo Pesa, Airtel Money and Banking Services across Tanzania.</p>
        </section>
        <section id="about">
          <h2>About Us</h2>
          <p>We provide mobile money and banking solutions for retail customers and agents.</p>
        </section>
        <section id="services">
          <h2>Services</h2>
          <ul>
            <li>M-Pesa</li>
            <li>Tigo Pesa</li>
            <li>Airtel Money</li>
            <li>NMB deposits, withdrawals, account opening and TTs</li>
            <li>CRDB deposits, withdrawals, account opening and TTs</li>
          </ul>
        </section>
        <section id="serve">
          <h2>Who We Serve</h2>
          <p>Retail customers and agents across Tanzania.</p>
        </section>
        <section id="contact">
          <h2>Contact</h2>
          <p>Email: info@example.com</p>
        </section>
      </main>
    </>
  )
}
